package com.prac;

public class user {
	public static void main(String[] args) {
		Calculator.add(20,30);
		System.out.println(Calculator.reverseString("Arjit"));
	}
	

}
