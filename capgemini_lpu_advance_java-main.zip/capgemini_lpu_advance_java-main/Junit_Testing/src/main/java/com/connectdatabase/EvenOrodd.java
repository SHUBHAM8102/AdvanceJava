package com.connectdatabase;

public class EvenOrodd {
	public String evenOrodd(int a) {
		if(a%2==0) {
			return "even";
		}
		else {
			return "odd";
		}
	}

}
